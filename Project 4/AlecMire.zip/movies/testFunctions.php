<?php
//
// This is not required, but it is recommended you decompose
// this problem into stand-alone tested functions.
//
include 'functions.php';

echo oneReview('princessbride');

echo PHP_EOL;

echo definitionList('tmnt');
?>